import sys
from collections import defaultdict

def count_tags(true_seqs, pred_seqs):
    """
    Count correct, true, and predicted occurrences of each tag.

    Parameters:
    - true_seqs: list of true tags
    - pred_seqs: list of predicted tags

    Returns:
    - correct_counts: correct tags per type
    - true_counts: true tags per type
    - pred_counts: predicted tags per type
    """
    correct_counts = defaultdict(int)
    true_counts = defaultdict(int)
    pred_counts = defaultdict(int)

    for true_tag, pred_tag in zip(true_seqs, pred_seqs):
        true_counts[true_tag] += 1
        pred_counts[pred_tag] += 1
        if true_tag == pred_tag:
            correct_counts[true_tag] += 1

    return correct_counts, true_counts, pred_counts

def calculate_metrics(correct_counts, true_counts, pred_counts):
    """
    Calculate precision, recall, and F1 score for each tag.

    Parameters:
    - correct_counts, true_counts, pred_counts: counts from count_tags

    Returns:
    - results: Dictionary of tuples containing precision, recall, and F1 for each tag
    """
    results = {}
    for tag in set(true_counts.keys()).union(set(pred_counts.keys())):
        precision = correct_counts[tag] / pred_counts[tag] if pred_counts[tag] > 0 else 0
        recall = correct_counts[tag] / true_counts[tag] if true_counts[tag] > 0 else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
        results[tag] = (precision, recall, f1)
    return results

def evaluate(true_seqs, pred_seqs, verbose=True):
    correct_counts, true_counts, pred_counts = count_tags(true_seqs, pred_seqs)
    results = calculate_metrics(correct_counts, true_counts, pred_counts)

    # Calculate overall metrics
    total_true = sum(true_counts.values())
    total_pred = sum(pred_counts.values())
    total_correct = sum(correct_counts.values())
    overall_prec = total_correct / total_pred if total_pred > 0 else 0
    overall_rec = total_correct / total_true if total_true > 0 else 0
    overall_f1 = 2 * overall_prec * overall_rec / (overall_prec + overall_rec) if (overall_prec + overall_rec) > 0 else 0

    if verbose:
        print(f"Total: {total_true} True, {total_pred} Predicted, {total_correct} Correct")
        print(f"Overall Precision: {overall_prec:.2f}, Recall: {overall_rec:.2f}, F1 Score: {overall_f1:.2f}")
        for tag, (precision, recall, f1) in results.items():
            print(f"{tag} - Precision: {precision:.2f}, Recall: {recall:.2f}, F1 Score: {f1:.2f}")

    return overall_prec, overall_rec, overall_f1, results
