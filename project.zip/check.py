"""
First run `python3 zipout.py` to create your output zipfile `output.zip` and output directory `./output`

Then run:

    python3 check.py

It will print out a score of all your outputs that matched the
testcases with a reference output file (typically `./references/dev/*.out`).
In some cases the output is supposed to fail in which case it
compares the `*.ret` files instead.

To customize the files used by default, run:

    python3 check.py -h
"""

import os
import sys
import argparse
import logging
from collections import defaultdict
import conlleval

def read_labels_from_file(filepath):
    """
    Reads labels from a file. Each line in the file corresponds to a label.
    """
    labels = []
    with open(filepath, 'r', encoding='utf-8') as file:
        for line in file:
            label = line.strip()
            labels.append(label)
    return labels

def evaluate_outputs(ref_dir, prediction_file):
    """
    Compares prediction file against all reference files in the reference directory.
    Assumes prediction and reference files are direct lists of labels, one per line.
    """
    scores = defaultdict(float)
    for ref_filename in os.listdir(ref_dir):
        ref_filepath = os.path.join(ref_dir, ref_filename)
        if os.path.isfile(ref_filepath):
            logging.info(f"Evaluating against reference file: {ref_filepath}")
            true_labels = read_labels_from_file(ref_filepath)
            pred_labels = read_labels_from_file(prediction_file)
            precision, recall, f1_score, _ = conlleval.evaluate(true_labels, pred_labels, verbose=False)
            scores[ref_filename] = f1_score
            print(f"Results for {ref_filename} - Precision: {precision:.4f}, Recall: {recall:.4f}, F1-Score: {f1_score:.4f}")
    return scores

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Check model performance against reference cases.")
    parser.add_argument("-t", "--refcases", dest="ref_dir", default=os.path.join('data', 'reference'), help="references directory [default: data/reference]")
    parser.add_argument("-z", "--zipfile", dest="zipfile", default='output.zip', help="zip file created by zipout.py [default: output.zip]")
    parser.add_argument("-l", "--logfile", dest="logfile", default=None, help="log file for debugging")
    parser.add_argument("-p", "--prediction_file", required=True, help="Path to the file containing the model's predictions.")
    args = parser.parse_args()

    if args.logfile:
        logging.basicConfig(filename=args.logfile, level=logging.DEBUG)

    scores = evaluate_outputs(args.ref_dir, args.prediction_file)
    total_score = sum(scores.values()) / len(scores) if scores else 0.0
    print(f"Average F1-Score across all reference files: {total_score:.4f}")