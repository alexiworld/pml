import os, sys, argparse, gzip, re, logging
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from transformers import AutoTokenizer, AutoModel
import tqdm 
import random

def model_in_training_mode():
    path_to_search = os.path.join("..", "data", "chunker.pt")
    return not os.path.exists(path_to_search)

# Initialize the tokenizer
tokenizer = AutoTokenizer.from_pretrained('distilbert-base-uncased')

def load_emotion_lexicon(filename):
    emotion_lexicon = {
        'anticipation': [], 'joy': [], 'surprise': [], 'trust': [],
        'anxiety': [], 'sadness': [], 'anger': [], 'disgust': []
    }
    with open(filename, 'r') as file:
        for line in file:
            parts = line.strip().split()
            word = parts[0]
            emotions_keys_list = list(emotion_lexicon.keys())  # Convert dict_keys to list
            for emotion in emotion_lexicon.keys():
                # Calculate the index we want to check
                index = 2 + emotions_keys_list.index(emotion) * 2
                # Make sure this index exists in parts
                if index < len(parts) and parts[index] == '1':
                    emotion_lexicon[emotion].append(word)
    return emotion_lexicon

# Load the emotion lexicon once
emotion_lexicon = load_emotion_lexicon(os.path.join('data', 'EmotionLexiconData.txt'))

def extract_emotional_content_with_transformers(text, emotion_lexicon):
    # Tokenize text and convert token IDs back to tokens
    token_ids = tokenizer.encode(text, add_special_tokens=False)
    tokens = [tokenizer.decode([token_id]).strip() for token_id in token_ids]
    
    total_tokens = len(tokens)
    
    # Initialize counts for each emotion
    emotion_counts = {emotion: 0 for emotion in emotion_lexicon.keys()}
    
    # Count occurrences of each emotion's words
    for token in tokens:
        for emotion, words in emotion_lexicon.items():
            if token.lower() in words:  # Convert tokens to lowercase to match with lexicon
                emotion_counts[emotion] += 1
    
    # Calculate emotional scores
    emotional_scores = {emotion: (count / total_tokens) * 100 for emotion, count in emotion_counts.items()}
    
    return emotional_scores

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

def read_conll(handle, instance):
    conll_data = []
    for line in handle:
        line = line.strip()
        if not line:
            continue  # skip empty lines
        if model_in_training_mode():
            conll_data.append(line) # Store text for testing
        else:
            parts = line.split(" - ")
            if len(parts) != 2:
                logging.warning(f"Skipping malformed line: {line}")
                continue
            text, label_str = parts
            label = instance.label_encoding.get(label_str.strip(), None)  # Access label_encoding from the instance
            if label is None:
                logging.warning(f"Unrecognized label: {label_str}")
                continue  # Skip lines with unrecognized labels
            conll_data.append(([text], [label]))  # Store text and numerical label
    return conll_data

class TransformerModel(nn.Module):

    def __init__(
            self,
            basemodel,
            tagset_size=3,
            lr=5e-5,
            emotion_feature_dim=8, 
            intermediate_dim=256
        ):
        torch.manual_seed(1)
        super(TransformerModel, self).__init__()
        self.basemodel = basemodel
        # the encoder will be a BERT-like model that receives an input text in subwords and maps each subword into
        # contextual representations
        self.encoder = None
        # the hidden dimension of the BERT-like model will be automatically set in the init function!
        self.encoder_hidden_dim = 0
        
        self.emotion_feature_dim = emotion_feature_dim
        self.intermediate_dim = intermediate_dim
        # The linear layer that maps the subword contextual representation space to tag space
        self.classification_head = None
        self.optimizers = None
        self.init_model_from_scratch(basemodel, tagset_size, lr)
        

    def init_model_from_scratch(self, basemodel, tagset_size, lr):
        self.encoder = AutoModel.from_pretrained(basemodel)
        self.encoder_hidden_dim = self.encoder.config.hidden_size
        self.classification_head = nn.Linear(self.encoder_hidden_dim, tagset_size)
        self.dense1 = nn.Linear(self.encoder_hidden_dim + self.emotion_feature_dim, self.intermediate_dim)  # Adjust dimensions as needed
        self.dense2 = nn.Linear(self.intermediate_dim, tagset_size)  # Adjust intermediate_dim as per your design

        encoder_optimizer = optim.Adam(self.encoder.parameters(), lr = lr)
        head_optimizer = optim.SGD(self.classification_head.parameters(), lr = 0.01)

        dense_layers_optimizer = optim.Adam([{'params': self.dense1.parameters()}, {'params': self.dense2.parameters()}], lr=0.01)

        self.optimizers = [encoder_optimizer, head_optimizer, dense_layers_optimizer]

    def forward(self, input_ids, emotion_features, attention_mask=None):
        # Get the last hidden state from the encoder
        encoded = self.encoder(input_ids, attention_mask=attention_mask).last_hidden_state
        
        # Extract the first token's representations (often used as the aggregate sequence representation in BERT-like models)
        combined_features = torch.cat((encoded[:, 0, :], emotion_features), dim=1)  # Concatenate along the last dimension (features dimension)

        # Pass the combined features through the first dense layer
        dense_output_1 = F.relu(self.dense1(combined_features))
        
        # Pass the output of the first dense layer through the second dense layer
        logits = self.dense2(dense_output_1)  # Output logits directly
        
        return logits


class FinetuneTagger:

    def __init__(
            self,
            modelfile,
            modelsuffix='.pt',
            basemodel='distilbert-base-uncased',
            trainfile=os.path.join('data', 'SafetyNetTrainingData.txt'),
            epochs=5,
            batchsize=4,
            lr=5e-5
        ):
        # the input sentences will be handled using this object, you do not need to manually encode input sentence words
        self.tokenizer = AutoTokenizer.from_pretrained(basemodel)
        self.trainfile = trainfile
        self.modelfile = modelfile
        self.modelsuffix = modelsuffix
        self.basemodel = basemodel
        self.epochs = epochs
        self.batchsize = batchsize
        self.lr = lr
        self.training_data = []
        self.tag_to_ix = {}  # replace output labels / tags with an index
        self.ix_to_tag = []  # during inference we produce tag indices so we have to map it back to a tag
        self.model = None # setup the model in self.decode() or self.train()
        # Define label encoding
        self.label_encoding = {
            "N": 0,  # Not Aggressive
            "A": 1,  # Aggressive
            "V": 2   # Violent
        }

    def load_training_data(self, trainfile):
        self.training_data = []
        with open(trainfile, 'r') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue  # Skip empty lines
                text, label = line.rsplit(" - ", 1)  # Split each line into text and label
                self.training_data.append((text, label))

        # Update tag_to_ix based on the labels found in the training data
        for _, labels in self.training_data:
            for label in labels:
                if label not in self.tag_to_ix:
                    self.tag_to_ix[label] = len(self.tag_to_ix)
                    self.ix_to_tag.append(label)

        logging.info("tag_to_ix: ".format(self.tag_to_ix))
        logging.info("ix_to_tag: ".format(self.ix_to_tag))

    def prepare_sequence(self, input_tokens_list, target_sequence=None):
        sentence_in = self.tokenizer(
            input_tokens_list,
            is_split_into_words=True,
            add_special_tokens=False,
            return_tensors="pt"
        )
        if target_sequence is not None:
            # Assuming target_sequence is a list with a single label for the whole sequence
            label_idx = self.tag_to_ix[target_sequence[0]]  # Convert the single label to its index
            target_tensor = torch.tensor([label_idx], dtype=torch.long)
            return sentence_in, target_tensor
        return sentence_in

    def argmax(self, model, seq):   
        with torch.no_grad():
            inputs = self.prepare_sequence([seq]).to(device)  # seq is a single sequence of text
            emotional_scores = extract_emotional_content_with_transformers(seq, emotion_lexicon)  # Extract emotional content
            emotional_features = torch.tensor(list(emotional_scores.values()), dtype=torch.float).unsqueeze(0).to(device)  # Convert to tensor and format appropriately

            # Forward pass through the model
            output = model(inputs['input_ids'], emotional_features)  # Assuming your model returns logits directly
            tag_scores = F.log_softmax(output, dim=1)  # Apply log softmax to compute probabilities

            predicted_label_index = torch.argmax(tag_scores, dim=1).item()  # Get the index of the highest score
            predicted_label = self.ix_to_tag[predicted_label_index]  # Map index back to label
            return predicted_label


    def train(self):
        self.load_training_data(self.trainfile)
        self.model = TransformerModel(self.basemodel, len(self.tag_to_ix), self.lr).to(device)
        loss_function = nn.CrossEntropyLoss()

        # Initializing optimizers here, inside the train method
        encoder_optimizer = optim.Adam(self.model.encoder.parameters(), lr=self.lr)
        head_optimizer = optim.SGD(self.model.classification_head.parameters(), lr=0.01)
        dense_layers_optimizer = optim.Adam([
            {'params': self.model.dense1.parameters()},
            {'params': self.model.dense2.parameters()}
        ], lr=0.01)
        optimizers = [encoder_optimizer, head_optimizer, dense_layers_optimizer]

        self.model.train()

        for epoch in range(self.epochs):
            total_loss = 0
            for input_text, label in tqdm.tqdm(self.training_data):
                inputs = self.tokenizer([input_text], padding=True, truncation=True, return_tensors="pt").to(device)
                label_tensor = torch.tensor([self.tag_to_ix[label]], dtype=torch.long).to(device)

                # Process emotional_features for the text
                emotional_scores = extract_emotional_content_with_transformers(input_text, emotion_lexicon)
                emotional_features = torch.tensor(list(emotional_scores.values()), dtype=torch.float).unsqueeze(0).to(device)

                #self.model.zero_grad()
                for optimizer in optimizers:
                    optimizer.zero_grad()
                outputs = self.model(inputs['input_ids'], emotional_features, inputs['attention_mask'])
                loss = loss_function(outputs, label_tensor)
                loss.backward()
                for optimizer in optimizers:
                    optimizer.step()
                total_loss += loss.item()

            avg_loss = total_loss / len(self.training_data)
            print(f"Epoch {epoch+1}/{self.epochs}, Avg Loss: {avg_loss:.4f}")

        # Save the model along with additional data
        model_save_path = f"{self.modelfile}_epoch_{epoch+1}{self.modelsuffix}"
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': [opt.state_dict() for opt in optimizers],
            'tag_to_ix': self.tag_to_ix,
            'ix_to_tag': self.ix_to_tag,
            'loss': avg_loss,
        }, model_save_path)
        print(f"Model saved to {model_save_path}")

    def model_str(self):
        if not os.path.isfile(self.modelfile + self.modelsuffix):
            raise IOError(f"Error: missing model file {self.modelfile + self.modelsuffix}")

        saved_model = torch.load(self.modelfile + self.modelsuffix)
        tag_to_ix = saved_model['tag_to_ix']
        ix_to_tag = saved_model['ix_to_tag']
        model = TransformerModel(self.basemodel, len(tag_to_ix), lr=self.lr).to(device)
        model.load_state_dict(saved_model['model_state_dict'])
        return str(model)

    def decode(self, inputfile, prediction_output_file='predictions.txt'):
        model_file_path = 'data/chunker_epoch_5.pt'  # Hardcoded path to the specific model file

        # Ensure the model file exists
        if not os.path.isfile(model_file_path):
            raise IOError(f"Error: missing model file {model_file_path}")

        # Load the saved model
        saved_model = torch.load(model_file_path, map_location=device)
        self.model.load_state_dict(saved_model['model_state_dict'])

        # Check if tag_to_ix is in the saved model, raise error if not
        if 'tag_to_ix' not in saved_model or 'ix_to_tag' not in saved_model:
            raise KeyError("Model file does not contain necessary tag mappings (tag_to_ix or ix_to_tag).")

        self.tag_to_ix = saved_model['tag_to_ix']
        self.ix_to_tag = saved_model['ix_to_tag']

        # Initialize the model for inference
        model = TransformerModel(self.basemodel, len(self.tag_to_ix), lr=self.lr).to(device)
        model.eval()

        # Reading input data
        with open(inputfile, 'r') as f:
            input_data = read_conll(f, self)

        # Generate predictions
        predictions = []
        for sent in tqdm.tqdm(input_data):
            predicted_label = self.argmax(model, sent)
            predictions.append(predicted_label)

        # Save predictions to a file
        with open(prediction_output_file, 'w') as f:
            for prediction in predictions:
                f.write(f"{prediction}\n")
        print(f"Predictions successfully written to {prediction_output_file}.")

        return predictions


if __name__ == '__main__':
    argparser = argparse.ArgumentParser()
    argparser.add_argument("-i", "--inputfile", dest="inputfile",
                            default=os.path.join('data', 'input', 'dev.txt'),
                             help="produce output for this input file")
    argparser.add_argument("-t", "--trainfile", dest="trainfile",
                            default=os.path.join('data', 'SafetyNetTrainingData.txt'),
                            help="training data for model")
    argparser.add_argument("-m", "--modelfile", dest="modelfile",
                            default=os.path.join('data', 'chunker'),
                            help="filename without suffix for model files")
    argparser.add_argument("-s", "--modelsuffix", dest="modelsuffix", default='.pt',
                            help="filename suffix for model files")
    argparser.add_argument("-M", "--basemodel", dest="basemodel",
                            default='distilbert-base-uncased',
                            help="The base huggingface pretrained model to be used as the encoder.")
    argparser.add_argument("-e", "--epochs", dest="epochs", type=int, default=5,
                            help="number of epochs [default: 5]")
    argparser.add_argument("-b", "--batchsize", dest="batchsize", type=int, default=16,
                            help="batch size [default: 16]")
    argparser.add_argument("-r", "--lr", dest="lr", type=float, default=5e-5,
                            help="the learning rate used to finetune the BERT-like encoder module.")
    argparser.add_argument("-f", "--force", dest="force", action="store_true", default=False,
                            help="force training phase (warning: can be slow)")
    argparser.add_argument("-l", "--logfile", dest="logfile", default=None,
                            help="log file for debugging")
    opts = argparser.parse_args()
    if opts.logfile is not None:
        logging.basicConfig(filename=opts.logfile, filemode='w', level=logging.DEBUG)
    modelfile = opts.modelfile
    if modelfile.endswith('.pt'):
        modelfile = modelfile.removesuffix('.pt')
    safetynet = FinetuneTagger(
                    modelfile,
                    modelsuffix=opts.modelsuffix,
                    basemodel=opts.basemodel,
                    trainfile=opts.trainfile,
                    epochs=opts.epochs,
                    batchsize=opts.batchsize,
                    lr=opts.lr
                )
    if not os.path.isfile(modelfile + opts.modelsuffix) or opts.force:
        print(f"Could not find modelfile {modelfile + opts.modelsuffix} or -f used. Starting training.", file=sys.stderr)
        safetynet.train()
        print("Training done.", file=sys.stderr)
    # use the model file if available and opts.force is False
    model_file_path = 'data/chunker_epoch_5.pt'
    assert os.path.isfile(model_file_path), f"Error: missing model file {model_file_path}"
    print(f"Found modelfile {modelfile + opts.modelsuffix}. Starting decoding.", file=sys.stderr)
    decoder_output = safetynet.decode(opts.inputfile)
    print("\n\n".join([ "\n".join(output) for output in decoder_output ]))